# C# Tutorial - Create a simple top down game in windows form
In this tutorial we make a fun little top down car racing game using windows form and C# inside of visual studio 2019. We will go through this project step by step and I will show how to import the images, set the form, add events and code the whole game. The main objective of this game is race as long as you can without hitting any other car in the road, if you do then the game is over.

We use a panel as the main game screen in this game. We are also using two picture boxes as the road marking and moving them to show a parallax scrolling animation inside of windows form. The final result came out really good and I am very happy with it. 

After the roads we add the cars for the AI and the car for the player, plan the collision detection and we are also going make a fun little feature where it gives you a trophy in the end of the for your score. Currently we have 3 trophies in this game a bronze one for a lower score, a silver one for a medium level score and a gold one for higher scores. 

The game changes based on the score so it makes it difficult to get higher score as you are playing. This tutorial was fun to do and I hope you find it useful for your own project. Once you become familiar with the game and you feel like you know what to do then try to add your features to this game and make it better.

Video Tutorial - 

[![](http://img.youtube.com/vi/YIgQg_AAIIU/0.jpg)](http://www.youtube.com/watch?v=YIgQg_AAIIU "MOO ICT top down car racing game in windows form")

Written Tutorial - https://www.mooict.com/c-tutorial-top-down-car-racing-game-with-visual-studio/

